// 변수를 선언합니다.
let numberA = Number.MAX_VALUE;
let numberB = Number.MAX_VALUE + 1;
// 출력합니다.
console.log(numberA);
console.log(numberB);
let array = [20,4,5,6,8,15];
let totarray = array.concat([7,8,9]);
console.log(array);
console.log(totarray);
console.log(array.join());
array.reverse();
console.log(array);
